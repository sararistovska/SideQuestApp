﻿document.addEventListener("DOMContentLoaded", () => {

    /* ---------------------------------------------
       MOBILE MENU
    --------------------------------------------- */

    const menuButton = document.querySelector(".sq-menu-toggle");
    const nav = document.querySelector(".sq-nav");

    if (menuButton && nav) {
        menuButton.addEventListener("click", () => {
            nav.classList.toggle("menu-open");
        });
    }


    /* ---------------------------------------------
       QUEST CARD TILT
    --------------------------------------------- */

    const cards = document.querySelectorAll(".sq-quest-card");

    cards.forEach(card => {

        card.addEventListener("mousemove", event => {

            const rect = card.getBoundingClientRect();

            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = ((y - centerY) / centerY) * -1.5;
            const rotateY = ((x - centerX) / centerX) * 1.5;

            card.style.transform =
                `translateY(-8px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });

        card.addEventListener("mouseleave", () => {
            card.style.transform = "";
        });

    });


    /* ---------------------------------------------
       SMOOTH SCROLL
    --------------------------------------------- */

    document.querySelectorAll('a[href^="#"]').forEach(link => {

        link.addEventListener("click", event => {

            const targetId = link.getAttribute("href");

            if (!targetId || targetId === "#") {
                return;
            }

            const target = document.querySelector(targetId);

            if (target) {

                event.preventDefault();

                target.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }

        });

    });


    /* ---------------------------------------------
       LITTLE HERO MOVEMENT
    --------------------------------------------- */

    const stamp = document.querySelector(".sq-hero-stamp");

    if (stamp) {

        window.addEventListener("scroll", () => {

            const scroll = window.scrollY;

            stamp.style.transform =
                `rotate(${10 + scroll * 0.025}deg)`;
        });

    }

});


/* ---------------------------------------------
   LEADERBOARD
--------------------------------------------- */

document.addEventListener("DOMContentLoaded", function () {

    const searchedPlayer =
        document.querySelector(".sq-search-target");

    if (!searchedPlayer) {
        return;
    }

    setTimeout(function () {

        searchedPlayer.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });

    }, 300);

});


/* ---------------------------------------------
   LIKES
--------------------------------------------- */

document.addEventListener("DOMContentLoaded", function () {

    document
        .querySelectorAll(".sq-like-form")
        .forEach(function (form) {

            const button =
                form.querySelector(".sq-like-button");

            const symbol =
                form.querySelector(".sq-like-symbol");

            const count =
                form.querySelector(".sq-like-count");

            const completionId =
                form.dataset.completionId;

            if (!button || !completionId) {
                return;
            }

            button.addEventListener(
                "click",
                async function () {

                    if (button.disabled) {
                        return;
                    }

                    button.disabled = true;

                    const isLiked =
                        button.dataset.liked === "true";

                    const action =
                        isLiked
                            ? "Unlike"
                            : "Like";

                    const tokenInput =
                        form.querySelector(
                            'input[name="__RequestVerificationToken"]'
                        );

                    if (!tokenInput) {

                        button.disabled = false;

                        return;
                    }

                    const token =
                        tokenInput.value;

                    try {

                        const response =
                            await fetch(
                                `/Feed/${action}?id=${completionId}`,
                                {
                                    method: "POST",
                                    headers: {
                                        "RequestVerificationToken":
                                        token,
                                        "X-Requested-With":
                                            "XMLHttpRequest"
                                    }
                                }
                            );

                        if (!response.ok) {
                            throw new Error(
                                "Like request failed."
                            );
                        }

                        const data =
                            await response.json();

                        if (!data.success) {
                            throw new Error(
                                "Like request failed."
                            );
                        }

                        button.dataset.liked =
                            data.liked.toString();

                        if (count) {
                            count.textContent =
                                data.likeCount;
                        }

                        if (data.liked) {

                            button.classList.add(
                                "sq-liked"
                            );

                            if (symbol) {
                                symbol.textContent = "♥";
                            }

                        } else {

                            button.classList.remove(
                                "sq-liked"
                            );

                            if (symbol) {
                                symbol.textContent = "♡";
                            }

                        }

                        button.classList.remove(
                            "sq-like-pop"
                        );

                        void button.offsetWidth;

                        button.classList.add(
                            "sq-like-pop"
                        );

                    }
                    catch (error) {

                        console.error(error);

                    }
                    finally {

                        button.disabled = false;

                    }

                }
            );

        });

});


/* ---------------------------------------------
   COPY GROUP CODE
--------------------------------------------- */

document.addEventListener(
    "click",
    async function (event) {

        const button =
            event.target.closest(
                ".sq-copy-code"
            );

        if (!button) {
            return;
        }

        const code =
            button.dataset.copyCode;

        if (!code) {
            return;
        }

        let copied = false;

        try {

            if (
                navigator.clipboard &&
                window.isSecureContext
            ) {

                await navigator.clipboard.writeText(
                    code
                );

                copied = true;
            }

        }
        catch {

            copied = false;

        }

        if (!copied) {

            const textarea =
                document.createElement(
                    "textarea"
                );

            textarea.value = code;

            textarea.style.position =
                "fixed";

            textarea.style.left =
                "-9999px";

            textarea.style.top =
                "0";

            document.body.appendChild(
                textarea
            );

            textarea.focus();
            textarea.select();

            textarea.setSelectionRange(
                0,
                textarea.value.length
            );

            try {

                copied =
                    document.execCommand(
                        "copy"
                    );

            }
            catch {

                copied = false;

            }

            document.body.removeChild(
                textarea
            );
        }

        const originalText =
            button.textContent;

        if (copied) {

            button.textContent =
                "Copied";

            setTimeout(function () {

                button.textContent =
                    originalText;

            }, 1600);

        }
        else {

            button.textContent =
                "Copy failed";

            setTimeout(function () {

                button.textContent =
                    originalText;

            }, 1600);

        }

    }
);


/* ---------------------------------------------
   PHOTO INPUT
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const photoInput =
            document.getElementById("photo");

        const fileName =
            document.getElementById(
                "sq-file-name"
            );

        const fileHint =
            document.getElementById(
                "sq-file-hint"
            );

        if (
            !photoInput ||
            !fileName ||
            !fileHint
        ) {
            return;
        }

        photoInput.addEventListener(
            "change",
            function () {

                if (
                    photoInput.files &&
                    photoInput.files.length > 0
                ) {

                    fileName.textContent =
                        photoInput.files[0].name;

                    fileHint.textContent =
                        "Photo selected";

                }
                else {

                    fileName.textContent =
                        "Choose a photo";

                    fileHint.textContent =
                        "JPG, PNG or WEBP";

                }

            }
        );

    }
);


/* =========================================================
   FRIEND REQUESTS
   SEND / CANCEL / ACCEPT / REJECT / REMOVE
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    function getFriendAction(form) {

        const dataAction =
            form.dataset.action || "";

        if (dataAction) {
            return dataAction;
        }

        const url =
            form.getAttribute("action") || "";

        const normalized =
            url.toLowerCase();

        if (normalized.includes("/friends/sendrequest")) {
            return "send";
        }

        if (normalized.includes("/friends/cancelrequest")) {
            return "cancel";
        }

        if (normalized.includes("/friends/accept")) {
            return "accept";
        }

        if (normalized.includes("/friends/reject")) {
            return "reject";
        }

        if (normalized.includes("/friends/remove")) {
            return "remove";
        }

        return "";
    }


    function getUsername(form) {

        const input =
            form.querySelector(
                'input[name="username"]'
            );

        if (input) {
            return input.value;
        }

        return form.dataset.username || "";
    }


    function setAddFriendState(form) {

        form.setAttribute(
            "action",
            "/Friends/SendRequest"
        );

        form.dataset.action =
            "send";

        const button =
            form.querySelector("button");

        if (!button) {
            return;
        }

        button.disabled = false;

        button.textContent =
            "Add friend";

        button.classList.remove(
            "sq-friend-action-secondary"
        );

        button.classList.add(
            "sq-friend-action-primary"
        );
    }


    function setCancelState(form) {

        form.setAttribute(
            "action",
            "/Friends/CancelRequest"
        );

        form.dataset.action =
            "cancel";

        const button =
            form.querySelector("button");

        if (!button) {
            return;
        }

        button.disabled = false;

        button.textContent =
            "Cancel request";

        button.classList.remove(
            "sq-friend-action-primary"
        );

        button.classList.add(
            "sq-friend-action-secondary"
        );
    }


    function removeFriendElement(element) {

        if (!element) {
            return;
        }

        element.style.transition =
            "opacity .22s ease, transform .22s ease";

        element.style.opacity =
            "0";

        element.style.transform =
            "translateY(-8px)";

        setTimeout(function () {
            element.remove();
        }, 220);
    }


    async function handleFriendForm(form) {

        const action =
            getFriendAction(form);

        if (!action) {
            return;
        }


        const username =
            getUsername(form);


        if (
            (action === "send" ||
                action === "cancel") &&
            !username
        ) {

            console.error(
                "No username found in friend form."
            );

            alert(
                "Username is missing."
            );

            return;
        }


        const button =
            form.querySelector("button");


        const originalText =
            button
                ? button.textContent.trim()
                : "";


        if (button) {

            button.disabled = true;

            button.textContent =
                "Loading...";
        }


        try {

            const formData =
                new FormData(form);


            if (
                username &&
                !formData.has("username")
            ) {

                formData.append(
                    "username",
                    username
                );
            }


            const response =
                await fetch(
                    form.getAttribute("action"),
                    {
                        method: "POST",
                        body: formData,
                        headers: {
                            "X-Requested-With":
                                "XMLHttpRequest"
                        },
                        credentials: "same-origin"
                    }
                );


            const responseText =
                await response.text();


            console.log(
                "Friend request response:",
                response.status,
                responseText
            );


            if (!response.ok) {

                let errorMessage =
                    "Request failed.";

                try {

                    const errorData =
                        JSON.parse(
                            responseText
                        );

                    if (errorData.message) {
                        errorMessage =
                            errorData.message;
                    }

                }
                catch {
                }


                throw new Error(
                    errorMessage +
                    " (" +
                    response.status +
                    ")"
                );
            }


            let data;

            try {

                data =
                    JSON.parse(
                        responseText
                    );

            }
            catch {

                throw new Error(
                    "Server did not return JSON."
                );
            }


            if (!data.success) {

                throw new Error(
                    data.message ||
                    "Friend request failed."
                );
            }


            /* SEND REQUEST */

            if (action === "send") {

                setCancelState(form);

                return;
            }


            /* CANCEL REQUEST */

            if (action === "cancel") {

                setAddFriendState(form);

                return;
            }


            /* ACCEPT REQUEST */

            if (action === "accept") {

                const person =
                    form.closest(
                        ".sq-friend-person"
                    );

                const card =
                    form.closest(
                        ".sq-friend-card"
                    );

                const element =
                    person || card;

                if (element) {

                    removeFriendElement(
                        element
                    );

                }
                else {

                    window.location.reload();

                }

                return;
            }


            /* REJECT REQUEST */

            if (action === "reject") {

                const person =
                    form.closest(
                        ".sq-friend-person"
                    );

                const card =
                    form.closest(
                        ".sq-friend-card"
                    );

                const element =
                    person || card;

                if (element) {

                    removeFriendElement(
                        element
                    );

                }
                else {

                    window.location.reload();

                }

                return;
            }


            /* REMOVE FRIEND */

            if (action === "remove") {

                const person =
                    form.closest(
                        ".sq-friend-person"
                    );

                const card =
                    form.closest(
                        ".sq-friend-card"
                    );

                const element =
                    person || card;

                if (element) {

                    removeFriendElement(
                        element
                    );

                }
                else {

                    window.location.reload();

                }

                return;
            }

        }
        catch (error) {

            console.error(
                "Friend request error:",
                error
            );


            if (button) {

                button.disabled =
                    false;

                button.textContent =
                    originalText ||
                    "Try again";
            }


            alert(
                error.message ||
                "Something went wrong. Please try again."
            );
        }

    }


    document.addEventListener(
        "submit",
        function (event) {

            const form =
                event.target.closest(
                    "form"
                );

            if (!form) {
                return;
            }


            const action =
                getFriendAction(form);


            const isFriendForm =
                form.classList.contains(
                    "sq-friend-ajax-form"
                );


            if (
                !action &&
                !isFriendForm
            ) {
                return;
            }


            event.preventDefault();


            handleFriendForm(form);

        }
    );

});


/* ---------------------------------------------
   QUEST CREATE
   CAPTION + PHOTO
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const photoInput =
            document.getElementById(
                "photo"
            );

        const fileName =
            document.getElementById(
                "sq-file-name"
            );

        const fileHint =
            document.getElementById(
                "sq-file-hint"
            );


        if (
            photoInput &&
            fileName &&
            fileHint
        ) {

            photoInput.addEventListener(
                "change",
                function () {

                    if (
                        this.files &&
                        this.files.length > 0
                    ) {

                        const file =
                            this.files[0];

                        fileName.textContent =
                            file.name;

                        fileHint.textContent =
                            `${(
                                file.size /
                                (1024 * 1024)
                            ).toFixed(2)} MB`;

                    }
                    else {

                        fileName.textContent =
                            "Choose a photo";

                        fileHint.textContent =
                            "JPG, JPEG, PNG or WEBP · max 10 MB";

                    }

                }
            );

        }


        const caption =
            document.getElementById(
                "caption"
            );

        const captionCount =
            document.getElementById(
                "sq-caption-count"
            );


        if (
            caption &&
            captionCount
        ) {

            function updateCaptionCount() {

                captionCount.textContent =
                    caption.value.length;
            }


            caption.addEventListener(
                "input",
                updateCaptionCount
            );


            updateCaptionCount();

        }

    }
);


/* ---------------------------------------------
   RESPONSIVE NAV
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const menuButton =
            document.querySelector(
                ".sq-mobile-menu-button"
            );

        const mobileNav =
            document.querySelector(
                ".sq-mobile-nav"
            );

        const overlay =
            document.querySelector(
                ".sq-mobile-nav-overlay"
            );


        if (
            !menuButton ||
            !mobileNav ||
            !overlay
        ) {

            return;
        }


        menuButton.addEventListener(
            "click",
            function () {

                menuButton.classList.toggle(
                    "is-open"
                );

                mobileNav.classList.toggle(
                    "is-open"
                );

                overlay.classList.toggle(
                    "is-open"
                );


                const isOpen =
                    mobileNav.classList.contains(
                        "is-open"
                    );


                menuButton.setAttribute(
                    "aria-expanded",
                    isOpen
                );


                document.body.classList.toggle(
                    "sq-mobile-menu-open",
                    isOpen
                );

            }
        );


        overlay.addEventListener(
            "click",
            function () {

                menuButton.classList.remove(
                    "is-open"
                );

                mobileNav.classList.remove(
                    "is-open"
                );

                overlay.classList.remove(
                    "is-open"
                );

                menuButton.setAttribute(
                    "aria-expanded",
                    "false"
                );

                document.body.classList.remove(
                    "sq-mobile-menu-open"
                );

            }
        );


        mobileNav
            .querySelectorAll("a")
            .forEach(
                function (link) {

                    link.addEventListener(
                        "click",
                        function () {

                            menuButton.classList.remove(
                                "is-open"
                            );

                            mobileNav.classList.remove(
                                "is-open"
                            );

                            overlay.classList.remove(
                                "is-open"
                            );

                            document.body.classList.remove(
                                "sq-mobile-menu-open"
                            );

                        }
                    );

                }
            );

    }
);


/* ---------------------------------------------
   INDEX QUESTS — BASIC FILTER
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const searchInput =
            document.getElementById(
                "questSearch"
            );

        const filters =
            document.querySelectorAll(
                ".sq-filter"
            );

        const cards =
            document.querySelectorAll(
                ".sq-quest-card"
            );

        const noResults =
            document.getElementById(
                "noQuestResults"
            );


        if (
            !searchInput ||
            !cards.length
        ) {

            return;
        }


        let activeDifficulty =
            "all";


        function filterQuests() {

            const search =
                searchInput.value
                    .trim()
                    .toLowerCase();


            let visibleCount =
                0;


            cards.forEach(
                function (card) {

                    const title =
                        (
                            card.dataset.title ||
                            ""
                        ).toLowerCase();


                    const category =
                        (
                            card.dataset.category ||
                            ""
                        ).toLowerCase();


                    const difficulty =
                        (
                            card.dataset.difficulty ||
                            ""
                        ).toLowerCase();


                    const matchesSearch =
                        title.includes(search) ||
                        category.includes(search);


                    const matchesDifficulty =
                        activeDifficulty === "all" ||
                        difficulty ===
                        activeDifficulty.toLowerCase();


                    if (
                        matchesSearch &&
                        matchesDifficulty
                    ) {

                        card.style.display =
                            "";

                        visibleCount++;

                    }
                    else {

                        card.style.display =
                            "none";
                    }

                }
            );


            if (noResults) {

                noResults.style.display =
                    visibleCount === 0
                        ? "block"
                        : "none";

            }

        }


        searchInput.addEventListener(
            "input",
            filterQuests
        );


        filters.forEach(
            function (filter) {

                filter.addEventListener(
                    "click",
                    function () {

                        filters.forEach(
                            function (button) {

                                button.classList.remove(
                                    "active"
                                );

                            }
                        );


                        filter.classList.add(
                            "active"
                        );


                        activeDifficulty =
                            filter.dataset.filter ||
                            "all";


                        filterQuests();

                    }
                );

            }
        );


        filterQuests();

    }
);


/* ---------------------------------------------
   QUEST CREATE — COMMUNITY GOAL
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const goalInput =
            document.getElementById(
                "CommunityGoal"
            );

        const goalPreview =
            document.getElementById(
                "goalPreview"
            );


        if (
            goalInput &&
            goalPreview
        ) {

            function updateGoal() {

                const value =
                    parseInt(
                        goalInput.value
                    );


                goalPreview.textContent =
                    value > 0
                        ? value
                        : "0";

            }


            goalInput.addEventListener(
                "input",
                updateGoal
            );


            updateGoal();

        }

    }
);


/* ---------------------------------------------
   QUEST FILTERING
   DIFFICULTY + CATEGORY + SEARCH
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const searchInput =
            document.getElementById(
                "questSearch"
            );


        const difficultyFilters =
            document.querySelectorAll(
                ".sq-filter"
            );


        const categoryFilters =
            document.querySelectorAll(
                ".sq-category-filter"
            );


        const cards =
            document.querySelectorAll(
                ".sq-quest-card"
            );


        const noResults =
            document.getElementById(
                "noQuestResults"
            );


        if (
            !searchInput ||
            !cards.length
        ) {

            return;
        }


        let activeDifficulty =
            "all";

        let activeCategory =
            "all";


        function filterQuests() {

            const search =
                searchInput.value
                    .trim()
                    .toLowerCase();


            let visibleCount =
                0;


            cards.forEach(
                function (card) {

                    const title =
                        (
                            card.dataset.title ||
                            ""
                        ).toLowerCase();


                    const category =
                        (
                            card.dataset.category ||
                            ""
                        ).toLowerCase();


                    const difficulty =
                        (
                            card.dataset.difficulty ||
                            ""
                        ).toLowerCase();


                    const matchesSearch =
                        title.includes(search) ||
                        category.includes(search);


                    const matchesDifficulty =
                        activeDifficulty === "all" ||
                        difficulty ===
                        activeDifficulty.toLowerCase();


                    const matchesCategory =
                        activeCategory === "all" ||
                        category ===
                        activeCategory.toLowerCase();


                    if (
                        matchesSearch &&
                        matchesDifficulty &&
                        matchesCategory
                    ) {

                        card.style.display =
                            "";

                        visibleCount++;

                    }
                    else {

                        card.style.display =
                            "none";

                    }

                }
            );


            if (noResults) {

                noResults.style.display =
                    visibleCount === 0
                        ? "block"
                        : "none";

            }

        }


        /* DIFFICULTY */

        difficultyFilters.forEach(
            function (filter) {

                filter.addEventListener(
                    "click",
                    function () {

                        difficultyFilters.forEach(
                            function (button) {

                                button.classList.remove(
                                    "active"
                                );

                            }
                        );


                        filter.classList.add(
                            "active"
                        );


                        activeDifficulty =
                            filter.dataset.filter ||
                            "all";


                        filterQuests();

                    }
                );

            }
        );


        /* CATEGORY */

        categoryFilters.forEach(
            function (filter) {

                filter.addEventListener(
                    "click",
                    function () {

                        categoryFilters.forEach(
                            function (button) {

                                button.classList.remove(
                                    "active"
                                );

                            }
                        );


                        filter.classList.add(
                            "active"
                        );


                        activeCategory =
                            filter.dataset.category ||
                            "all";


                        filterQuests();

                    }
                );

            }
        );


        /* SEARCH */

        searchInput.addEventListener(
            "input",
            filterQuests
        );


        filterQuests();

    }
);


/* ---------------------------------------------
   UNIFIED MODALS
   QUEST MODALS + COMMUNITY POST MODALS
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const modals =
            document.querySelectorAll(
                ".sq-quest-modal"
            );

        if (!modals.length) {
            return;
        }


        /* OPEN MODAL */

        function openModal(modal) {

            if (!modal) {
                return;
            }

            modal.classList.add(
                "is-open"
            );

            modal.setAttribute(
                "aria-hidden",
                "false"
            );

            document.body.classList.add(
                "sq-modal-open"
            );
        }


        /* CLOSE MODAL */

        function closeModal(modal) {

            if (!modal) {
                return;
            }

            modal.classList.remove(
                "is-open"
            );

            modal.setAttribute(
                "aria-hidden",
                "true"
            );


            const anyOpenModal =
                document.querySelector(
                    ".sq-quest-modal.is-open"
                );


            if (!anyOpenModal) {

                document.body.classList.remove(
                    "sq-modal-open"
                );

            }

        }


        /* QUEST MODALS */

        document
            .querySelectorAll(
                "[data-quest-modal]"
            )
            .forEach(
                function (button) {

                    button.addEventListener(
                        "click",
                        function (event) {

                            event.preventDefault();

                            const questId =
                                button.getAttribute(
                                    "data-quest-modal"
                                );

                            if (!questId) {
                                return;
                            }


                            const modal =
                                document.getElementById(
                                    "questModal-" +
                                    questId
                                );


                            openModal(
                                modal
                            );

                        }
                    );

                }
            );


        /* COMMUNITY POST MODALS */

        document
            .querySelectorAll(
                "[data-completion-modal]"
            )
            .forEach(
                function (post) {

                    post.addEventListener(
                        "click",
                        function (event) {

                            const noModal =
                                event.target.closest(
                                    "[data-no-modal]"
                                );

                            if (noModal) {
                                return;
                            }


                            const modal =
                                document.getElementById(
                                    "communityPostModal"
                                );

                            if (!modal) {
                                return;
                            }


                            const username =
                                post.dataset.username ||
                                "User";

                            const date =
                                post.dataset.date ||
                                "";

                            const caption =
                                post.dataset.caption ||
                                "";

                            const photo =
                                post.dataset.photo ||
                                "";

                            const points =
                                post.dataset.points ||
                                "0";

                            const profile =
                                post.dataset.profile ||
                                "#";


                            const modalImage =
                                document.getElementById(
                                    "communityModalImage"
                                );

                            const modalUsername =
                                document.getElementById(
                                    "communityModalUsername"
                                );

                            const modalDate =
                                document.getElementById(
                                    "communityModalDate"
                                );

                            const modalCaption =
                                document.getElementById(
                                    "communityModalCaption"
                                );

                            const modalCaptionWrapper =
                                document.getElementById(
                                    "communityModalCaptionWrapper"
                                );

                            const modalPoints =
                                document.getElementById(
                                    "communityModalPoints"
                                );

                            const modalAvatar =
                                document.getElementById(
                                    "communityModalAvatar"
                                );


                            if (modalImage) {

                                modalImage.src =
                                    photo;

                                modalImage.alt =
                                    username +
                                    " completed a quest";

                            }


                            if (modalUsername) {

                                modalUsername.textContent =
                                    username;

                                modalUsername.href =
                                    profile;

                            }


                            if (modalDate) {

                                modalDate.textContent =
                                    date;

                            }


                            if (modalCaption) {

                                modalCaption.textContent =
                                    caption;

                            }


                            if (modalCaptionWrapper) {

                                modalCaptionWrapper.style.display =
                                    caption.trim()
                                        ? ""
                                        : "none";

                            }


                            if (modalPoints) {

                                modalPoints.textContent =
                                    "+" +
                                    points +
                                    " points";

                            }


                            if (modalAvatar) {

                                modalAvatar.textContent =
                                    username
                                        .charAt(0)
                                        .toUpperCase();

                            }


                            openModal(
                                modal
                            );

                        }
                    );

                }
            );


        /* ALL MODAL CLOSE BUTTONS */

        document
            .querySelectorAll(
                ".sq-quest-modal [data-modal-close], " +
                ".sq-quest-modal [data-close-quest-modal]"
            )
            .forEach(
                function (button) {

                    button.addEventListener(
                        "click",
                        function (event) {

                            event.preventDefault();

                            const modal =
                                button.closest(
                                    ".sq-quest-modal"
                                );

                            closeModal(
                                modal
                            );

                        }
                    );

                }
            );


        /* ESCAPE */

        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key !==
                    "Escape"
                ) {
                    return;
                }


                const openModalElement =
                    document.querySelector(
                        ".sq-quest-modal.is-open"
                    );


                if (openModalElement) {

                    closeModal(
                        openModalElement
                    );

                }

            }
        );

    }
);


/* ---------------------------------------------
   SUBMIT QUEST — FRIEND SEARCH
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const searchInput =
            document.getElementById(
                "sq-friend-search"
            );

        const friendsList =
            document.getElementById(
                "sq-friends-list"
            );

        const emptyMessage =
            document.getElementById(
                "sq-friends-empty"
            );


        if (
            !searchInput ||
            !friendsList
        ) {
            return;
        }


        const friendOptions =
            Array.from(
                friendsList.querySelectorAll(
                    ".sq-friend-option"
                )
            );


        searchInput.addEventListener(
            "input",
            function () {

                const searchValue =
                    searchInput.value
                        .trim()
                        .toLowerCase();

                let visibleCount =
                    0;


                friendOptions.forEach(
                    function (friend) {

                        const username =
                            friend.getAttribute(
                                "data-username"
                            ) || "";

                        const matches =
                            username.includes(
                                searchValue
                            );

                        friend.style.display =
                            matches
                                ? "flex"
                                : "none";

                        if (matches) {
                            visibleCount++;
                        }

                    }
                );


                if (emptyMessage) {

                    emptyMessage.style.display =
                        visibleCount === 0
                            ? "block"
                            : "none";
                }

            }
        );

    }
);


/* ---------------------------------------------
   DARK MODE
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const themeToggle =
            document.getElementById(
                "themeToggle"
            );

        if (!themeToggle) {
            return;
        }


        const savedTheme =
            localStorage.getItem(
                "sidequest-theme"
            );


        if (savedTheme === "dark") {

            document.body.classList.add(
                "sq-dark"
            );

        }


        updateThemeIcon();


        themeToggle.addEventListener(
            "click",
            function () {

                document.body.classList.toggle(
                    "sq-dark"
                );


                const isDark =
                    document.body.classList.contains(
                        "sq-dark"
                    );


                localStorage.setItem(
                    "sidequest-theme",
                    isDark
                        ? "dark"
                        : "light"
                );


                updateThemeIcon();

            }
        );


        function updateThemeIcon() {

            const isDark =
                document.body.classList.contains(
                    "sq-dark"
                );


            themeToggle.classList.toggle(
                "is-dark",
                isDark
            );

        }

    }
);


/* =========================================================
   SIDEQUEST — COOKIE CONSENT
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const cookieBanner =
            document.getElementById(
                "cookieBanner"
            );

        const cookieModal =
            document.getElementById(
                "cookieModal"
            );

        const cookieAccept =
            document.getElementById(
                "cookieAccept"
            );

        const cookieNecessary =
            document.getElementById(
                "cookieNecessary"
            );

        const cookieManage =
            document.getElementById(
                "cookieManage"
            );

        const cookieSave =
            document.getElementById(
                "cookieSave"
            );

        const cookieAcceptModal =
            document.getElementById(
                "cookieAcceptModal"
            );

        const cookieModalClose =
            document.getElementById(
                "cookieModalClose"
            );

        const cookieModalBackdrop =
            document.getElementById(
                "cookieModalBackdrop"
            );

        const cookieSettings =
            document.getElementById(
                "cookieSettings"
            );

        const analyticsCookies =
            document.getElementById(
                "analyticsCookies"
            );

        const COOKIE_NAME =
            "sidequest-cookie-consent";


        function getConsent() {

            const cookies =
                document.cookie.split(";");


            for (let cookie of cookies) {

                cookie =
                    cookie.trim();


                if (
                    cookie.startsWith(
                        COOKIE_NAME + "="
                    )
                ) {

                    try {

                        return JSON.parse(
                            decodeURIComponent(
                                cookie.substring(
                                    COOKIE_NAME.length + 1
                                )
                            )
                        );

                    }
                    catch {

                        return null;

                    }

                }

            }

            return null;
        }


        function saveConsent(analytics) {

            const consent = {
                essential: true,
                analytics: analytics,
                timestamp:
                    new Date().toISOString()
            };


            const expires =
                new Date();


            expires.setFullYear(
                expires.getFullYear() + 1
            );


            document.cookie =
                COOKIE_NAME +
                "=" +
                encodeURIComponent(
                    JSON.stringify(consent)
                ) +
                "; expires=" +
                expires.toUTCString() +
                "; path=/; SameSite=Lax";


            hideBanner();
            closeModal();

        }


        function showBanner() {

            if (!cookieBanner) {
                return;
            }


            cookieBanner.hidden =
                false;


            requestAnimationFrame(
                function () {

                    cookieBanner.classList.add(
                        "is-visible"
                    );

                }
            );

        }


        function hideBanner() {

            if (!cookieBanner) {
                return;
            }


            cookieBanner.classList.remove(
                "is-visible"
            );


            setTimeout(
                function () {

                    cookieBanner.hidden =
                        true;

                },
                250
            );

        }


        function openModal() {

            if (!cookieModal) {
                return;
            }


            const consent =
                getConsent();


            if (analyticsCookies) {

                analyticsCookies.checked =
                    consent?.analytics === true;

            }


            cookieModal.hidden =
                false;


            requestAnimationFrame(
                function () {

                    cookieModal.classList.add(
                        "is-visible"
                    );

                }
            );


            document.body.classList.add(
                "sq-cookie-modal-open"
            );

        }


        function closeModal() {

            if (!cookieModal) {
                return;
            }


            cookieModal.classList.remove(
                "is-visible"
            );


            setTimeout(
                function () {

                    cookieModal.hidden =
                        true;

                },
                200
            );


            document.body.classList.remove(
                "sq-cookie-modal-open"
            );

        }


        cookieAccept?.addEventListener(
            "click",
            function () {

                saveConsent(true);

            }
        );


        cookieNecessary?.addEventListener(
            "click",
            function () {

                saveConsent(false);

            }
        );


        cookieManage?.addEventListener(
            "click",
            function () {

                openModal();

            }
        );


        cookieSave?.addEventListener(
            "click",
            function () {

                const analyticsEnabled =
                    analyticsCookies?.checked === true;

                saveConsent(
                    analyticsEnabled
                );

            }
        );


        cookieAcceptModal?.addEventListener(
            "click",
            function () {

                saveConsent(true);

            }
        );


        cookieModalClose?.addEventListener(
            "click",
            function () {

                closeModal();

            }
        );


        cookieModalBackdrop?.addEventListener(
            "click",
            function () {

                closeModal();

            }
        );


        cookieSettings?.addEventListener(
            "click",
            function () {

                openModal();

            }
        );


        const existingConsent =
            getConsent();


        if (!existingConsent) {
            showBanner();
        }

    }
);


/* =========================================================
   SIDEQUEST — NOTIFICATIONS
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const notificationToggle =
            document.getElementById(
                "notificationToggle"
            );

        const notificationDropdown =
            document.getElementById(
                "notificationDropdown"
            );


        if (
            !notificationToggle ||
            !notificationDropdown
        ) {
            return;
        }


        notificationToggle.addEventListener(
            "click",
            function (event) {

                event.stopPropagation();


                const isOpen =
                    notificationDropdown.classList.contains(
                        "is-open"
                    );


                notificationDropdown.classList.toggle(
                    "is-open",
                    !isOpen
                );


                notificationToggle.setAttribute(
                    "aria-expanded",
                    (!isOpen).toString()
                );

            }
        );


        notificationDropdown.addEventListener(
            "click",
            function (event) {

                event.stopPropagation();

            }
        );


        document.addEventListener(
            "click",
            function () {

                notificationDropdown.classList.remove(
                    "is-open"
                );


                notificationToggle.setAttribute(
                    "aria-expanded",
                    "false"
                );

            }
        );

    }
);


/* ---------------------------------------------
   CATEGORIES DROPDOWN IN QUESTS
--------------------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const categoryFilter =
            document.getElementById(
                "categoryFilter"
            );

        const questCards =
            document.querySelectorAll(
                ".sq-quest-card"
            );


        if (!categoryFilter) {
            return;
        }


        categoryFilter.addEventListener(
            "change",
            function () {

                const selectedCategory =
                    this.value.toLowerCase();


                questCards.forEach(
                    function (card) {

                        const cardCategory =
                            (
                                card.dataset.category ||
                                ""
                            ).toLowerCase();


                        if (
                            selectedCategory === "all" ||
                            cardCategory === selectedCategory
                        ) {

                            card.style.display =
                                "";

                        }
                        else {

                            card.style.display =
                                "none";

                        }

                    }
                );

            }
        );

    }
);